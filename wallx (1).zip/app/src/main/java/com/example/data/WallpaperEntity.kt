package com.example.data

import androidx.compose.runtime.Immutable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Immutable
@Entity(tableName = "wallpapers")
data class WallpaperEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val filePath: String,
    val width: Int,
    val height: Int,
    val fileSizeBytes: Long,
    val isFavorite: Boolean = false,
    val tag: String = "",
    val addedAt: Long = System.currentTimeMillis()
) {
    val resolutionLabel: String
        get() = when {
            tag.equals("16K", ignoreCase = true) || width >= 7680 || height >= 7680 -> "16K ULTRA"
            width > 0 && height > 0 -> "${width} × ${height}"
            else -> "16K ULTRA"
        }
}
