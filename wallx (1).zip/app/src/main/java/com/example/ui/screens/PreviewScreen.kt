package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Precision
import com.example.R
import com.example.data.WallpaperEntity
import com.example.ui.components.EditWallpaperBottomSheet
import com.example.ui.components.LiquidGlassButton
import com.example.ui.components.LiquidGlassIconButton
import com.example.ui.components.LiquidGlassStyle
import com.example.ui.components.LiquidGlassSurface
import com.example.ui.theme.BrushedSilverLight
import java.io.File

private val PreviewTopScrim = Brush.verticalGradient(
    colors = listOf(Color(0x96000000), Color.Transparent)
)

private val PagerSnapSpec = spring<Float>(
    dampingRatio = Spring.DampingRatioNoBouncy,
    stiffness = Spring.StiffnessMediumLow
)

@Composable
fun PreviewScreen(
    wallpapers: List<WallpaperEntity>,
    initialWallpaperId: Long,
    isOwner: Boolean,
    isApplying: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: (WallpaperEntity) -> Unit,
    onUpdateDetails: (id: Long, title: String, tag: String) -> Unit,
    onDeleteWallpaper: (WallpaperEntity) -> Unit,
    onSetPhoneScreen: (WallpaperEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (wallpapers.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Color.White)
        }
        return
    }

    val initialIndex = remember(initialWallpaperId, wallpapers.isEmpty()) {
        wallpapers.indexOfFirst { it.id == initialWallpaperId }.coerceAtLeast(0)
    }

    val pagerState = rememberPagerState(
        initialPage = initialIndex.coerceIn(0, (wallpapers.size - 1).coerceAtLeast(0)),
        pageCount = { wallpapers.size }
    )

    var editingWallpaper by remember { mutableStateOf<WallpaperEntity?>(null) }
    var deletingWallpaper by remember { mutableStateOf<WallpaperEntity?>(null) }

    val smoothFlingBehavior = PagerDefaults.flingBehavior(
        state = pagerState,
        snapPositionalThreshold = 0.22f,
        snapAnimationSpec = PagerSnapSpec
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Isolated VerticalPager: NEVER recomposes when top/bottom chrome updates on page settle
        VerticalPager(
            state = pagerState,
            beyondViewportPageCount = 1,
            flingBehavior = smoothFlingBehavior,
            key = { page -> wallpapers.getOrNull(page)?.id ?: page.toLong() },
            modifier = Modifier
                .fillMaxSize()
                .testTag("preview_vertical_pager")
        ) { page ->
            val item = wallpapers.getOrNull(page) ?: return@VerticalPager
            val pageRequest = remember(item.filePath) {
                ImageRequest.Builder(context)
                    .data(File(item.filePath))
                    .memoryCacheKey("${item.filePath}_preview_540")
                    .placeholderMemoryCacheKey("${item.filePath}_thumb_200")
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.DISABLED)
                    .size(540, 1170)
                    .precision(Precision.INEXACT)
                    .allowHardware(true)
                    .allowRgb565(true)
                    .crossfade(false)
                    .build()
            }

            AsyncImage(
                model = pageRequest,
                contentDescription = stringResource(R.string.cd_wallpaper_image, item.title),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            )
        }

        // Top subtle legibility scrim
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(124.dp)
                .align(Alignment.TopCenter)
                .background(PreviewTopScrim)
        )

        // Isolated Top Bar so page changes only recompose this lightweight header
        PreviewTopBar(
            wallpapers = wallpapers,
            pagerState = pagerState,
            onBack = onBack,
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // Isolated Bottom Action Dock — direct Phone Screen apply only (no Home/Lock screen menus)
        PreviewBottomDock(
            wallpapers = wallpapers,
            pagerState = pagerState,
            isOwner = isOwner,
            isApplying = isApplying,
            onToggleFavorite = onToggleFavorite,
            onEditClick = { editingWallpaper = it },
            onDeleteClick = { deletingWallpaper = it },
            onSetPhoneScreen = onSetPhoneScreen,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    val targetEdit = editingWallpaper
    if (isOwner && targetEdit != null) {
        EditWallpaperBottomSheet(
            wallpaper = targetEdit,
            onDismiss = { editingWallpaper = null },
            onSave = { newTitle, newTag ->
                editingWallpaper = null
                onUpdateDetails(targetEdit.id, newTitle, newTag)
            }
        )
    }

    val targetDelete = deletingWallpaper
    if (isOwner && targetDelete != null) {
        AlertDialog(
            onDismissRequest = { deletingWallpaper = null },
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            title = {
                Text(
                    text = stringResource(R.string.delete_dialog_title),
                    style = MaterialTheme.typography.headlineSmall
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.delete_dialog_message),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                LiquidGlassButton(
                    onClick = {
                        deletingWallpaper = null
                        onDeleteWallpaper(targetDelete)
                    },
                    style = LiquidGlassStyle.CORAL_DANGER,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                    modifier = Modifier.testTag("confirm_delete_wallpaper_button")
                ) {
                    Text(
                        text = stringResource(R.string.action_delete),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            },
            dismissButton = {
                LiquidGlassButton(
                    onClick = { deletingWallpaper = null },
                    style = LiquidGlassStyle.FROST_WHITE,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = stringResource(R.string.action_cancel),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        )
    }
}

@Composable
private fun PreviewTopBar(
    wallpapers: List<WallpaperEntity>,
    pagerState: PagerState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val safePageIndex by remember(wallpapers.size) {
        derivedStateOf { pagerState.currentPage.coerceIn(0, (wallpapers.size - 1).coerceAtLeast(0)) }
    }
    val currentWallpaper = wallpapers[safePageIndex]

    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        LiquidGlassIconButton(
            onClick = onBack,
            size = 48.dp,
            style = LiquidGlassStyle.DARK_OVERLAY,
            contentColor = Color.White,
            modifier = Modifier.testTag("preview_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.cd_back)
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = currentWallpaper.title,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = currentWallpaper.resolutionLabel,
                style = MaterialTheme.typography.labelSmall,
                color = BrushedSilverLight,
                fontWeight = FontWeight.Bold
            )
        }

        if (wallpapers.size > 1) {
            LiquidGlassSurface(
                style = LiquidGlassStyle.DARK_OVERLAY,
                shape = CircleShape,
                cornerRadius = 16.dp
            ) {
                Text(
                    text = "${safePageIndex + 1}/${wallpapers.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        } else {
            Spacer(modifier = Modifier.size(48.dp))
        }
    }
}

@Composable
private fun PreviewBottomDock(
    wallpapers: List<WallpaperEntity>,
    pagerState: PagerState,
    isOwner: Boolean,
    isApplying: Boolean,
    onToggleFavorite: (WallpaperEntity) -> Unit,
    onEditClick: (WallpaperEntity) -> Unit,
    onDeleteClick: (WallpaperEntity) -> Unit,
    onSetPhoneScreen: (WallpaperEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val safePageIndex by remember(wallpapers.size) {
        derivedStateOf { pagerState.currentPage.coerceIn(0, (wallpapers.size - 1).coerceAtLeast(0)) }
    }
    val currentWallpaper = wallpapers[safePageIndex]

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurface(
            style = LiquidGlassStyle.DARK_OVERLAY,
            shape = RoundedCornerShape(34.dp),
            cornerRadius = 34.dp,
            modifier = Modifier.widthIn(max = 520.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LiquidGlassIconButton(
                    onClick = { onToggleFavorite(currentWallpaper) },
                    size = 48.dp,
                    style = if (currentWallpaper.isFavorite) {
                        LiquidGlassStyle.MINT_PRIMARY
                    } else {
                        LiquidGlassStyle.DARK_OVERLAY
                    },
                    contentColor = if (currentWallpaper.isFavorite) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        Color.White
                    },
                    modifier = Modifier.testTag("preview_favorite_button")
                ) {
                    Icon(
                        imageVector = if (currentWallpaper.isFavorite) {
                            Icons.Filled.Favorite
                        } else {
                            Icons.Outlined.FavoriteBorder
                        },
                        contentDescription = stringResource(
                            if (currentWallpaper.isFavorite) R.string.cd_favorite_remove
                            else R.string.cd_favorite_add
                        ),
                        modifier = Modifier.size(21.dp)
                    )
                }

                if (isOwner) {
                    LiquidGlassIconButton(
                        onClick = { onEditClick(currentWallpaper) },
                        size = 48.dp,
                        style = LiquidGlassStyle.DARK_OVERLAY,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("preview_edit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = stringResource(R.string.cd_edit_details),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    LiquidGlassIconButton(
                        onClick = { onDeleteClick(currentWallpaper) },
                        size = 48.dp,
                        style = LiquidGlassStyle.DARK_OVERLAY,
                        contentColor = Color(0xFFFFB4B4),
                        modifier = Modifier.testTag("preview_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = stringResource(R.string.cd_delete_wallpaper),
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                // Direct Phone Screen wallpaper button ONLY (no Home Screen / Lock Screen dialog)
                LiquidGlassButton(
                    onClick = { onSetPhoneScreen(currentWallpaper) },
                    enabled = !isApplying,
                    style = LiquidGlassStyle.MINT_PRIMARY,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("preview_set_wallpaper_button")
                ) {
                    if (isApplying) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.applying_wallpaper),
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Smartphone,
                            contentDescription = null,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.action_set_phone_screen),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
