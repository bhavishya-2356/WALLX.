package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode — Pure White, Metallic Silver & Jet Black
val PureWhite = Color(0xFFFFFFFF)
val AlabasterWhite = Color(0xFFF5F6F8)
val SilverSurfaceLowest = Color(0xFFFFFFFF)
val SilverSurfaceLow = Color(0xFFF1F3F6)
val SilverSurface = Color(0xFFE9ECF1)
val SilverSurfaceHigh = Color(0xFFDFE3EA)
val SilverSurfaceHighest = Color(0xFFD4D9E2)

val JetBlack = Color(0xFF0B0C0E)              // Primary accent, buttons, active pill & deep ink
val CharcoalBlack = Color(0xFF1D2026)         // Secondary dark metallic highlight
val OnJetBlack = Color(0xFFFFFFFF)            // Crisp white ink over black controls
val SilverContainer = Color(0xFFE7EBEF)       // Soft brushed silver container
val OnSilverContainer = Color(0xFF111317)     // Deep ink on silver container

val ChromeSilver = Color(0xFF7B8290)          // Metallic silver accent (wordmark X & secondary badges)
val BrushedSilverLight = Color(0xFFE2E6ED)    // Crisp silver-white ink for dark wallpaper overlays
val GraphiteText = Color(0xFF5A616E)          // High-readability secondary body text on white
val SilverOutline = Color(0xFFC9CFD9)         // Clean metallic silver border
val SilverOutlineVariant = Color(0xFFDFE3EB)  // Subtle silver card border

// Dark Mode — Deep Obsidian Black, Brushed Silver & Platinum White
val DarkObsidianBg = Color(0xFF090A0D)
val DarkSurfaceLowest = Color(0xFF0E1015)
val DarkSurfaceLow = Color(0xFF14171D)
val DarkSurface = Color(0xFF1A1E26)
val DarkSurfaceHigh = Color(0xFF222731)
val DarkSurfaceHighest = Color(0xFF2C323F)
val DarkSilverOutline = Color(0xFF343B49)
val DarkSilverOutlineVariant = Color(0xFF252A35)
val DarkSilverText = Color(0xFFA0A7B5)
val PlatinumWhite = Color(0xFFF4F6FA)

val CrimsonError = Color(0xFFDC2626)
val CrimsonErrorContainer = Color(0xFFFEE2E2)
val OnCrimsonErrorContainer = Color(0xFF7F1D1D)
val DarkCrimsonError = Color(0xFFF87171)
val DarkCrimsonErrorContainer = Color(0xFF3F1515)
val DarkOnCrimsonErrorContainer = Color(0xFFFECACA)
