package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalWallxDarkTheme

enum class LiquidGlassStyle {
    MINT_PRIMARY,   // Primary action pill (Jet Black in Light Mode, Platinum White in Dark Mode)
    FROST_WHITE,    // Card / secondary surface (Pure White + Silver in Light Mode, Carbon Black + Silver in Dark Mode)
    DARK_OVERLAY,   // Smoked Obsidian overlay with Silver-White rim (over wallpapers)
    CORAL_DANGER    // Crimson alert surface for destructive confirmations
}

// Pre-allocated flat solid colors for zero gradient shader allocation & maximum frame rate
private val LightPrimaryBlackFill = Color(0xFF101216)
private val LightPrimaryBorder = Color(0xFF2B303A)
private val LightCardFill = Color(0xFFFFFFFF)
private val LightCardBorder = Color(0xFFD5DAE3)

private val DarkPrimaryWhiteFill = Color(0xFFF3F6FA)
private val DarkPrimaryBorder = Color(0xFFFFFFFF)
private val DarkCardFill = Color(0xFF14171D)
private val DarkCardBorder = Color(0xFF2E3442)

private val DarkOverlayFillColor = Color(0xCC0D0E12)
private val DarkOverlayBorderColor = Color(0x4DFFFFFF)

/**
 * Pure solid theme background with ZERO continuous redraws for silky scrolling.
 */
@Composable
fun Modifier.wallxBackdrop(): Modifier = this.background(MaterialTheme.colorScheme.background)

/**
 * Lightweight, zero-overdraw White, Silver & Black surface container supporting Light & Dark Mode.
 */
@Composable
fun LiquidGlassSurface(
    modifier: Modifier = Modifier,
    style: LiquidGlassStyle = LiquidGlassStyle.FROST_WHITE,
    shape: Shape = RoundedCornerShape(24.dp),
    cornerRadius: Dp = 24.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalWallxDarkTheme.current
    val errorColor = MaterialTheme.colorScheme.error

    val styledModifier = when (style) {
        LiquidGlassStyle.MINT_PRIMARY -> modifier
            .clip(shape)
            .background(if (isDark) DarkPrimaryWhiteFill else LightPrimaryBlackFill, shape)
            .border(1.dp, if (isDark) DarkPrimaryBorder else LightPrimaryBorder, shape)

        LiquidGlassStyle.FROST_WHITE -> modifier
            .clip(shape)
            .background(if (isDark) DarkCardFill else LightCardFill, shape)
            .border(1.dp, if (isDark) DarkCardBorder else LightCardBorder, shape)

        LiquidGlassStyle.DARK_OVERLAY -> modifier
            .clip(shape)
            .background(DarkOverlayFillColor, shape)
            .border(1.dp, DarkOverlayBorderColor, shape)

        LiquidGlassStyle.CORAL_DANGER -> modifier
            .clip(shape)
            .background(errorColor, shape)
            .border(1.dp, Color.White.copy(alpha = 0.35f), shape)
    }

    Box(
        modifier = styledModifier,
        content = content
    )
}

@Composable
fun LiquidGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: LiquidGlassStyle = LiquidGlassStyle.MINT_PRIMARY,
    shape: Shape = CircleShape,
    cornerRadius: Dp = 28.dp,
    contentPadding: PaddingValues = PaddingValues(horizontal = 22.dp, vertical = 12.dp),
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    val contentColor = when (style) {
        LiquidGlassStyle.MINT_PRIMARY -> MaterialTheme.colorScheme.onPrimary
        LiquidGlassStyle.CORAL_DANGER -> MaterialTheme.colorScheme.onError
        LiquidGlassStyle.DARK_OVERLAY -> Color.White
        LiquidGlassStyle.FROST_WHITE -> MaterialTheme.colorScheme.onSurface
    }.copy(alpha = if (enabled) 1f else 0.45f)

    LiquidGlassSurface(
        style = style,
        shape = shape,
        cornerRadius = cornerRadius,
        modifier = modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
    ) {
        CompositionLocalProvider(LocalContentColor provides contentColor) {
            Row(
                modifier = Modifier
                    .clickable(
                        enabled = enabled,
                        interactionSource = interactionSource,
                        indication = ripple(color = contentColor),
                        onClick = onClick
                    )
                    .padding(contentPadding),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                content = content
            )
        }
    }
}

@Composable
fun LiquidGlassIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    enabled: Boolean = true,
    style: LiquidGlassStyle = LiquidGlassStyle.FROST_WHITE,
    contentColor: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    val resolvedTint = contentColor ?: when (style) {
        LiquidGlassStyle.MINT_PRIMARY -> MaterialTheme.colorScheme.onPrimary
        LiquidGlassStyle.CORAL_DANGER -> MaterialTheme.colorScheme.onError
        LiquidGlassStyle.DARK_OVERLAY -> Color.White
        LiquidGlassStyle.FROST_WHITE -> MaterialTheme.colorScheme.onSurface
    }

    LiquidGlassSurface(
        style = style,
        shape = CircleShape,
        cornerRadius = size / 2,
        modifier = modifier.size(size)
    ) {
        CompositionLocalProvider(LocalContentColor provides resolvedTint) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        enabled = enabled,
                        interactionSource = interactionSource,
                        indication = ripple(bounded = true, color = resolvedTint),
                        onClick = onClick
                    ),
                contentAlignment = Alignment.Center,
                content = content
            )
        }
    }
}

@Composable
fun LiquidGlassChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    cornerRadius: Dp = 20.dp,
    minHeight: Dp = 40.dp
) {
    val interactionSource = remember { MutableInteractionSource() }

    val textColor = if (selected) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    LiquidGlassSurface(
        style = if (selected) LiquidGlassStyle.MINT_PRIMARY else LiquidGlassStyle.FROST_WHITE,
        shape = shape,
        cornerRadius = cornerRadius,
        modifier = modifier.defaultMinSize(minHeight = minHeight)
    ) {
        Box(
            modifier = Modifier
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(color = textColor),
                    onClick = onClick
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
