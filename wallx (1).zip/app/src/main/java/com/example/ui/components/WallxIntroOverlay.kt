package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ChromeSilver
import com.example.ui.theme.OutfitFontFamily

/**
 * Snappy, ultra-lightweight ~0.85s GPU-only startup animation.
 *
 * Uses a single Animatable(0f..1f) driving pure GPU graphicsLayer transforms (zero Canvas
 * redraws, zero offscreen buffers, zero recompositions) and mounts the home screen cleanly
 * right at completion so startup is instant and stutter-free on every device.
 */
@Composable
fun WallxIntroOverlay(
    onMountUnderlay: () -> Unit,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(0f) }

    val colorScheme = MaterialTheme.colorScheme
    val bgColor = colorScheme.background
    val primaryColor = colorScheme.primary
    val onPrimaryColor = colorScheme.onPrimary
    val outlineColor = colorScheme.outline
    val secondaryTextColor = colorScheme.onSurfaceVariant

    LaunchedEffect(Unit) {
        withFrameNanos { }
        // Phase 1 (0f -> 0.75f over 620ms): Fast crisp kinetic reveal with zero UI contention
        progress.animateTo(
            targetValue = 0.75f,
            animationSpec = tween(durationMillis = 620, easing = LinearEasing)
        )
        // Mount main screen and smoothly fade out over 220ms
        onMountUnderlay()
        withFrameNanos { }
        progress.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 220, easing = LinearEasing)
        )
        onFinished()
    }

    val titleText = remember {
        buildAnnotatedString {
            append("WALL")
            withStyle(SpanStyle(color = ChromeSilver)) {
                append("X")
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                val exit = easeOutCubic(segment(progress.value, 0.75f, 1.00f))
                alpha = 1f - exit
            }
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = titleText,
                style = TextStyle(
                    fontFamily = OutfitFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 48.sp,
                    letterSpacing = 5.sp,
                    color = primaryColor
                ),
                modifier = Modifier.graphicsLayer {
                    val e = easeOutCubic(segment(progress.value, 0.00f, 0.36f))
                    alpha = e
                    translationY = 14f * (1f - e)
                    val s = 0.95f + 0.05f * e
                    scaleX = s
                    scaleY = s
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.graphicsLayer {
                    val b = easeOutCubic(segment(progress.value, 0.14f, 0.48f))
                    alpha = b
                    translationY = 10f * (1f - b)
                }
            ) {
                Text(
                    text = stringResource(R.string.intro_quality_tag),
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 3.2.sp),
                    color = onPrimaryColor,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(primaryColor)
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                )

                Text(
                    text = stringResource(R.string.intro_wallpaper_name),
                    style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 2.8.sp),
                    color = secondaryTextColor,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 72.dp)
                .width(120.dp)
                .height(3.dp)
                .clip(CircleShape)
                .background(outlineColor.copy(alpha = 0.45f))
                .graphicsLayer {
                    alpha = easeOutCubic(segment(progress.value, 0.10f, 0.32f))
                }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0.5f)
                        scaleX = easeOutCubic(segment(progress.value, 0.04f, 0.75f)).coerceIn(0.02f, 1f)
                    }
                    .background(primaryColor)
            )
        }
    }
}

private fun segment(t: Float, start: Float, end: Float): Float {
    if (end <= start) return 1f
    return ((t - start) / (end - start)).coerceIn(0f, 1f)
}

private fun easeOutCubic(x: Float): Float {
    val inv = 1f - x
    return 1f - inv * inv * inv
}
